<?php
$id = $_GET['id'];
require_once "config.php";
$sql = "SELECT * FROM clients WHERE id = '$id'";
$result = $conn->query($sql);
  while($row = $result->fetch_assoc()) {
        $name = $row['name'];
        $contact = $row['contact'];
        $email = $row['email'];
    }
$conn->close();
?>
<html>
<form name= "f2" action="update.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $id ?>">
        <label>Name: </label>
        <input type="text" name="name" value="<?php echo $name ?>">
        <label>Contact No.: </label>
        <input type="text" name="contact" value="<?php echo $contact ?>">
        <label>Email: </label>
        <input type="text" name="email" value="<?php echo $email ?>">
    <input type="submit" value="done">
</form>
</html>
