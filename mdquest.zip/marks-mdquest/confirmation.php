<?php
require_once "config.php";
$name = $_POST["name"];
$doctor = $_POST["doctor"];
$specialty = $_POST["specialty"];
$contact = $_POST["contact"];
$email = $_POST["email"];
$address = $_POST["address"];
$contactno = $_POST["contact-no"];
$emailadd = $_POST["email-add"];
$sql = "INSERT INTO `clients`(`name`, `contact`, `email`, `doctor`, `date_assigned`) VALUES ('$name','$contactno','$emailadd','$doctor', CURDATE())";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
  $sql2 = "SELECT * FROM `clients` WHERE name = '$name' AND doctor = '$doctor'";
  $result = $conn->query($sql2);
  while($row = $result->fetch_assoc()) {
        $id = $row['id'];
    }
    echo "<br><a href=". 'find-reference.php?reference-no=' .$id. ">Okay</a>";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
?>
