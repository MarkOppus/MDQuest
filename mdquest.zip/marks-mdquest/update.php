<?php
$id = $_POST["id"];
$name = $_POST["name"];
$contact = $_POST["contact"];
$email = $_POST["email"];
require_once "config.php";
if(count($_POST)>0) {
$sql = "UPDATE `clients` SET name='$name', contact='$contact', email='$email' WHERE id='$id'";
  if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
    echo "<br><a href=". 'index.php' . ">Done</a>";
  } else {
    echo "Error updating record: " . $conn->error;
  }
}
$conn->close();
?>
