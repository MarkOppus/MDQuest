<?php
$id = $_GET["id"];
require_once "config.php";
$sql = "DELETE FROM `clients` WHERE id = $id";
if (mysqli_query($conn, $sql)) {
  echo "Record deleted successfully";
  echo "<br><a href=". 'index.php' . ">Okay</a>";
} else {
  echo "Error deleting record: " . mysqli_error($conn);
}

mysqli_close($conn);
?>
