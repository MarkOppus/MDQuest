<?php
$name = $_GET["name"];
$doctor = $_GET["doctor"];
$specialty = $_GET["specialty"];
$contact = $_GET["contact"];
$email = $_GET["email"];
$address = $_GET["address"];
?>
<html>
<title>
  Book form
</title>
<body>
  <h1>Hello <?php echo $name;?>!</h1>
  <h2>Your doctor details</h2>
  <p>Name: <b><?php echo $doctor;?></b></p>
  <p>Specialty: <b><?php echo $specialty;?></b></p>
  <p>Contact No: <b><?php echo $contact;?></b></p>
  <p>Email address: <b><?php echo $email;?></b></p>
  <p>Address: <b><?php echo $address;?></b></p>
  <h3>Please complete your details below to complete your reservation.</h3>
  <form name = "form" action="confirmation.php" method="POST" onsubmit="return validate()">
          <input type="hidden" name="name" value="<?php echo $name ?>">
          <input type="hidden" name="doctor" value="<?php echo $doctor ?>">
          <input type="hidden" name="specialty" value="<?php echo $specialty ?>">
          <input type="hidden" name="contact" value="<?php echo $contact ?>">
          <input type="hidden" name="email" value="<?php echo $email ?>">
          <input type="hidden" name="address" value="<?php echo $address ?>">
          <label>Contact No.: </label>
          <input type="text" name="contact-no"></br>
          <label>Email: </label>
          <input type="text" name="email-add">
      <input type="submit" value="Book now">
  </form>
</body>
<script>
function validate() {
  var a = document.forms["form"]["contact-no"].value;
  var b = document.forms["form"]["email"].value;
  if (a == "" || b == "") {
    alert("Name must be filled out");
    return false;
  }
}
</script>
</html>
