<html>

<form name= "f1" action="doctors-list.php" method="GET" onsubmit="return validate1()">
        <label>Name: </label>
        <input type="text" name="name">
    <input type="submit" value="Book now ">
</form>

<form name= "f2" action="find-reference.php" method="GET" onsubmit="return validate2()">
        <label>Reference No.: </label>
        <input type="text" name="reference-no">
    <input type="submit" value="Search reference">
</form>

<script>
function validate1() {
  var x = document.forms["f1"]["name"].value;
  if (x == "") {
    alert("Name must be filled out");
    return false;
  }
}
function validate2() {
  var x = document.forms["f2"]["name"].value;
  if (x == "") {
    alert("Name must be filled out");
    return false;
  }
}
</script>
</html>
