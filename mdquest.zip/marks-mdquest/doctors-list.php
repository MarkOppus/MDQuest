<?php
$name = $_GET["name"];
require_once "config.php";
$sql = "SELECT * FROM doctors";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
echo "<h1>Hello ".$name ."!!</h1>";
    echo "<table>";
      echo "<tr>";
          echo "<th>Name</th>";
          echo "<th>Specialty</th> ";
          echo "<th>Contact</th>";
          echo "<th>Email</th>";
          echo "<th>Address</th>";
      echo "</tr>";
    while($row = $result->fetch_assoc()) {
      echo "<tr>";
          echo "<td>" . $row['name'] . "</td>";
          echo "<td>" . $row['specialty'] . "</td>";
          echo "<td>" . $row['contact'] . "</td>";
          echo "<td>" . $row['email'] . "</td>";
          echo "<td>" . $row['address'] . "</td>";
          echo "<td>" . "<a href='booker.php?name=". $name ."&doctor=". $row['name'] ."&specialty=". $row['specialty'] ."&contact=". $row['contact'] ."&email=". $row['email'] ."&address=". $row['address'] ."'>Book</a>" . "</td>";
      echo "</tr>";
      }
    echo "</table>";
    } else {
    echo "0 results";
}
$conn->close();
?>
</body>
</html>
