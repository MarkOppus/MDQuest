<?php
$id = $_GET["reference-no"];
require_once "config.php";
$sql = "SELECT * FROM clients WHERE id = $id";
$result = $conn->query($sql);
while($row = $result->fetch_assoc()) {
        $id = $row['id'];
        $name = $row['name'];
        $contact = $row['contact'];
        $email = $row['email'];
        $doctor = $row['doctor'];
        $date_assigned = $row['date_assigned'];
    }
    $conn->close();
?>
<html>
<body>
  <h1>
    Hello <?php echo $name; ?>!
  </h1>
  <h3>
    Your doctor is <?php echo $doctor; ?>
  </h3>
  <p>Your assigned date is <b><?php echo $date_assigned; ?></b></p>
  <h2>Check your details so your doctor can contact you anytime</h2>
  <p>Contact number: <?php echo $contact; ?></p>
  <p>Email address: <?php echo $email; ?></p>
  <b><p>Reference number: <?php echo $id; ?></p><b>
  <br><a href="index.php">Done</a>
  <br><a href="edit-details.php?id=<?php echo $id; ?>">Edit</a>
  <br><a href="delete.php?id=<?php echo $id; ?>">Cancel</a>
</body>
</html>
